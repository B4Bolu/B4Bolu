const searchInput = document.getElementById('searchBar');
const products = document.querySelectorAll('.product-box');

searchInput.addEventListener('input', (e) => {
  const searchText = e.target.value.toLowerCase();
  products.forEach((product) => {
    const productName = product.querySelector('.product-title').textContent.toLowerCase();
    if (productName.includes(searchText)) {
      product.style.display = '';
    } else {
      product.style.display = 'none';
    }
  });
});l
